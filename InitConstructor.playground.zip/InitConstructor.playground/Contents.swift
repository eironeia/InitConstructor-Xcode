
import UIKit

//Add the variables and the types here
var constructor:[String: String] = [
    "startTime": "Int",
    "endTime": "Int",
    "frequencyNotification": "Int"
]


var initConstructor:String = "init ("
var initBody:String = ""
var constructorAux = constructor.dropLast()

for (variable, type) in constructor {
    print("var \(variable): \(type)") //Variable definitions
    initConstructor += "\(variable): \(type), "
    initBody += "   self.\(variable) = \(variable)\n"
}

//removing last comma and space
initConstructor.removeLast()
initConstructor.removeLast()

initConstructor += ") {"

// Init constructor
print("\n")
print(initConstructor)
print(initBody)
print("}")



